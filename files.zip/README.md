<div align="center">

<img src="./assets/banner.jpeg" alt="Banner" width="100%"/>

<br/>

# Olá, eu sou o Greg! 👋

### Data Engineer | Data Analytics

<br/>

<a href="https://www.linkedin.com/in/SEU-USUARIO-AQUI" target="_blank">
  <img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn"/>
</a>

</div>

<br/>

## 🛠️ Tecnologias

<div align="center">

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![SQL](https://img.shields.io/badge/SQL-4479A1?style=for-the-badge&logo=postgresql&logoColor=white)
![Power BI](https://img.shields.io/badge/Power_BI-F2C811?style=for-the-badge&logo=powerbi&logoColor=black)
![Oracle](https://img.shields.io/badge/Oracle-F80000?style=for-the-badge&logo=oracle&logoColor=white)
![Data Engineer](https://img.shields.io/badge/Data_Engineer-2E8B57?style=for-the-badge&logo=databricks&logoColor=white)
![Data Analytics](https://img.shields.io/badge/Data_Analytics-4B0082?style=for-the-badge&logo=googleanalytics&logoColor=white)

</div>

<br/>

## 🚀 Sobre mim

Trabalho com engenharia de dados construindo pipelines ETL e dashboards analíticos, com foco em ambientes Oracle (ODI, OAS, SQL) e sistemas financeiros governamentais. Tenho experiência também com Power BI, Node.js e integrações em nuvem (Azure/AWS).

<img src="./assets/toad-wizard.jpeg" alt="Toad Mago" width="140" align="right"/>

Curioso por natureza, gosto de mergulhar fundo em performance de queries, otimização de ETL e boas práticas de modelagem de dados. Atualmente cursando pós-graduação em Data Science.

<br clear="right"/>

<br/>

## 📊 Performance & Estatísticas

<div align="center">

<img src="https://github-readme-stats.vercel.app/api?username=SEU-USUARIO-AQUI&show_icons=true&theme=tokyonight&count_private=true" alt="GitHub Stats" height="165"/>
<img src="https://streak-stats.demolab.com?user=SEU-USUARIO-AQUI&theme=tokyonight" alt="GitHub Streak" height="165"/>

<br/>

<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=SEU-USUARIO-AQUI&layout=compact&theme=tokyonight" alt="Top Languages"/>

<br/><br/>

<img src="https://github-readme-activity-graph.vercel.app/graph?username=SEU-USUARIO-AQUI&theme=tokyo-night" alt="Activity Graph" width="100%"/>

</div>

<br/>

## 🎮 Modo relax

<div align="center">

<img src="./assets/toad-pool.jpeg" alt="Toad relaxando" width="150"/>
&nbsp;&nbsp;&nbsp;
<img src="./assets/kirby.jpeg" alt="Kirby" width="150"/>

<br/>
<sub>Quando não estou otimizando queries, estou aqui recarregando as energias 🌟</sub>

</div>

<br/>

## 📫 Contato

<div align="center">

<a href="https://www.linkedin.com/in/SEU-USUARIO-AQUI" target="_blank">
  <img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn"/>
</a>
<a href="mailto:SEU-EMAIL-AQUI" target="_blank">
  <img src="https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white" alt="Email"/>
</a>

</div>

<br/>

<div align="center">
<sub>✨ Feito com café e algumas queries SQL bem otimizadas ✨</sub>
</div>
